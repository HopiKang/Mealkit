package com.example.mealkit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MealkitApplication {

	public static void main(String[] args) {
		SpringApplication.run(MealkitApplication.class, args);
	}

}
